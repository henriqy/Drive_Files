#Inserindo dado nas tabelas 

insert into cliente (codigo, nome, cpf, end_rua, end_num, end_bairro, end_cep)
values('1','Thiago','00000000000','r.itabuna','26', 'francis', '69097777');

insert into cliente (codigo, nome, cpf, end_rua, end_num, end_bairro, end_cep)
values('2','rafa','10000000000','r.itabuna','22', 'francis', '69097771');

insert into cliente (codigo, nome, cpf, end_rua, end_num, end_bairro, end_cep)
values('3','dudu','13000000000','r.itabuna','23', 'francis', '69097721');

select codigo, nome from cliente;

delete from cliente where() 
