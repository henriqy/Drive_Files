<?php

$numCarteira =  56873;

for($i = 1; $i <= 25; $i++){

    $numCarteira =  $numCarteira + 1;
    print" ".$numCarteira." ";
}

?>