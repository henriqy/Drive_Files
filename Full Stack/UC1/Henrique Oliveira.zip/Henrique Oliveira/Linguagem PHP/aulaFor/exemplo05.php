<?php

for($i = 0; ; $i+=5){
    echo $i . "<br>";
    
}

?>