<?php

$meses = array("janeiro", "fevereiro",
                "marco", "abril", "Maio", "Junho");

foreach($meses as $mes){
    echo "O mes e: $mes <br>";
}

?>