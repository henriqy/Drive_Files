<?php

$peso = 10;

if($peso <= 10){
    $valorTotal = 3 * $peso;
    echo "valor total: $valorTotal R$";

} else {
    $valorTotal = 2 * $peso;
    echo "valor total: $valorTotal";

}

?>