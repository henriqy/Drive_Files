<?php

echo 5;
echo "<br>";
echo 55;
echo "<br>";
echo 555;

?>