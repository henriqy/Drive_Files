<?php
$numero = 1;

echo $c;
?>

