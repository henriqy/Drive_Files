<?php

// ****Configuracao basica de um computador****

/*
Memoria RAM = 32GB
Processador = Intel(R) Core(TM) i7-10700T CPU @ 2.00GHz   1.99 GHz
Tipo de Sistema = Sistema operacional de 64 bits, processador baseado em x64
*/

?>
