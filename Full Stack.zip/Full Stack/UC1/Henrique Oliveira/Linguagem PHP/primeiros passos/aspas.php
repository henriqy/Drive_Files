<?php
echo "testando aspas simples";
echo "<br>";
echo "testando aspas duplas";
echo "<br>";

$nome = "carlos";
$idade = 19;

echo "Me chamo $nome e tenho $idade anos";

?>