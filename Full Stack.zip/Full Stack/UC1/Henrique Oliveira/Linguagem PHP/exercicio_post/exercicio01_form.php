<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Validar a Nota</title>

</head>
<body>
    <h1>Validar Nota</h1>

    <main>
        <br><br>
        <div class ="conteiner">
            <form action="exercicio01_proc.php" method="POST">
                Nota: <input type="int" name="nota" placehoder="digite seu nome" required> <br><br>

                <input type="submit" value="Cadastrar">
            </form>
    </main>
</body>
</html>