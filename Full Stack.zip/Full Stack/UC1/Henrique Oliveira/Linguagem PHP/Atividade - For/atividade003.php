<?php

for($i = 300; $i > 0; $i--){

    if($i <= 200 && $i >= 100){
        continue;   
        
    }
    print "Ficha nº: $i \n";
    
}

?>