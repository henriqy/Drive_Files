<?php

$num = 10;

for($i = $num; $i <= $num + 50; $i++){
    print $i . " ";
}

$hoje = date('d/m/Y  H:i:s');
echo "\n". $hoje;

?>