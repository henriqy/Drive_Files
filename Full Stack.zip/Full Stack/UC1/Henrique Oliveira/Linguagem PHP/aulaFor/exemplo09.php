<?php

$meses = array("janeiro", "fevereiro",
                "marco", "abril", "Maio", "Junho");

foreach($meses as $index => $mes){
    
    echo "O index: $index <br>";
    
    echo "O mes e: $mes <br>";
}

?>