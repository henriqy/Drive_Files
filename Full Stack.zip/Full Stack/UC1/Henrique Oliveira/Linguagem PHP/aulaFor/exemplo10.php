<?php

$frutas = array ("Abacaxi", "Manga", "Laranja", "Banana", "Maça", "Pêra",
"Limão");
//Acessando uma posição no vetor
echo $frutas[3]. "<br>";

for($i = 0; $i <= 6; $i++){
    echo $frutas[$i] . "<br>";

}

?>