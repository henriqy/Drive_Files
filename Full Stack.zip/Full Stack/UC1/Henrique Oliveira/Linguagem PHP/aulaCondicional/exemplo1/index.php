<?php

/*
* Criar uma aplicacao para 
*analizar a idade de uma pessoa
*/

$qualSuaIdade = 15;

$idadeMenor = 17;

$idadeMaior = 18;

$idadeMelhor = 69;

if($qualSuaIdade <= $idadeMenor){
    echo "Voce eh menor de idade";

}
?>
