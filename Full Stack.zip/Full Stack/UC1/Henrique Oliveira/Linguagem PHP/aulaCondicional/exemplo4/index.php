<?php

$idade = 18;
$altura = 1.75;

if ($idade >= 18 && $altura > 1.70) {
    echo "pode competir";
} else {
    "nao pode competir";
}