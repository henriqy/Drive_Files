<?php

$nome = "Ana";
$sexo = "F";
$idade = "18";

if($sexo == "F" && ($idade >= 18 && $idade < 25)){
    echo "$nome, ACEITA";

}else{
    echo "$nome, NAO ACEITA";

}

?>