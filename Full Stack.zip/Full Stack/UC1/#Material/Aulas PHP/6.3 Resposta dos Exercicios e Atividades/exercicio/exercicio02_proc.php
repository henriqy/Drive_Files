<?php 
    $Titulo = $_POST["Titulo"];
    $Conteudo = $_POST["Conteudo"];

        echo $Titulo;
        echo "<br>";
        echo $Conteudo;
?>