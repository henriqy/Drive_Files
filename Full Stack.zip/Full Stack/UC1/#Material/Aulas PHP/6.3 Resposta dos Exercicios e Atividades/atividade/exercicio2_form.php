
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atividade Dois</title>
</head>
<body>
    <h1>Calcular o Salário</h1>
    <form action="exercicio2_proc.php" method="POST">
            Código: <input type="int" name="codigo" placeholder="Digite o seu código" required>
            <br><br>
            Salário: <input type="int" name="salario" placeholder="Digite o seu salário atual" required>
            <br><br>
            <input type="submit" value="Validar">
            <br><br>

    </form>
</body>
</html>